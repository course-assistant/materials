import Vue from 'vue'
import Index from './student-evaluate'

const index = new Vue(Index)

index.$mount()
