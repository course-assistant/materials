| key                                 | 含义                  |
| ----------------------------------- | --------------------- |
| `hncj_management_admin_token`       | 当前管理员token       |
| `hncj_management_teacher_token`     | 当前教师token         |
| `hncj_management_student_token`     | 当前学生token         |
| `hncj_assistant_web_teacher_id`     | web端当前教师用户id   |
| `hncj_assistant_web_teacher_name`   | web端当前教师用户姓名 |
| `hncj_assistant_web_teacher_avatar` | web端当前教师用户头像 |

