import Vue from 'vue'
import Index from './help'

const index = new Vue(Index)

index.$mount()
