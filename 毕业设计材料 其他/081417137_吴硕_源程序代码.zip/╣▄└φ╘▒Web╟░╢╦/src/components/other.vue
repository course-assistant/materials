<template>
  <div>
    <h1>备用页面</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>
</style>