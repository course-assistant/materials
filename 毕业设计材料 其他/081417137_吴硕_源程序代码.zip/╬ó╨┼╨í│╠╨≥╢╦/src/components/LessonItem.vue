<template>
  <div class="lesson-item">
   <div>lesson</div>
  </div>
</template>

<script>
export default {
  props: ['lesson'],
}
</script>

<style lang="scss" scoped>
.lesson-item {
  width: 100%;
  background: #fff;

 
}
</style>