import Vue from 'vue'
import Index from './welcome'

const index = new Vue(Index)

index.$mount()
