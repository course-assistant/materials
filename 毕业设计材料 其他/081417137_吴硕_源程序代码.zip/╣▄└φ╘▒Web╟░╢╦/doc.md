# 文档

## 1 本地存储

本地存储使用 `localStorage` 

统一加上前缀 `hncj_management_`