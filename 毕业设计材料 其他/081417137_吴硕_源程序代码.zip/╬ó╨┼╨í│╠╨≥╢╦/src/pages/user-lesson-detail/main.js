import Vue from 'vue'
import Index from './user-lesson-detail'

const index = new Vue(Index)

index.$mount()
