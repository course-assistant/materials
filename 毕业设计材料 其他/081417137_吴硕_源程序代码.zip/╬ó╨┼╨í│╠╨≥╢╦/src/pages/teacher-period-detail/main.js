import Vue from 'vue'
import Index from './teacher-period-detail'

const index = new Vue(Index)

index.$mount()
