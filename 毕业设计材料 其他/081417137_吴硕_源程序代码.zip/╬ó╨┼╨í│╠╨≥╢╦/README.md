# assistant-mobile
课程助手 微信小程序端

![QR](./小程序QR.png)