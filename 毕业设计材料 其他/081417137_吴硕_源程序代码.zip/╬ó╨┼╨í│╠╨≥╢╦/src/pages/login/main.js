import Vue from 'vue'
import Index from './login'

const index = new Vue(Index)

index.$mount()
