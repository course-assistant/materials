<template>
  <div>
    这是选择的页面
  </div>
</template>

<script>
  export default {
    name: "Choice"
  }
</script>

<style scoped>

</style>