import Vue from 'vue'
import Index from './student-course-detail'

const index = new Vue(Index)

index.$mount()
