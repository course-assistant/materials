import Vue from 'vue'
import Index from './teacher-course-detail'

const index = new Vue(Index)

index.$mount()
