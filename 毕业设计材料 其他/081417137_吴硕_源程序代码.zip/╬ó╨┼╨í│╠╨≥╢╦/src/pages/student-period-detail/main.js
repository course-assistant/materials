import Vue from 'vue'
import Index from './student-period-detail'

const index = new Vue(Index)

index.$mount()
