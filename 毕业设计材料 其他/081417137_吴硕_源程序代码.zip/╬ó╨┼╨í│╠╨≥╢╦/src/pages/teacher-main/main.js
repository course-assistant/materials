import Vue from 'vue'
import Index from './teacher-main'

const index = new Vue(Index)

index.$mount()
