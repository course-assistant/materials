import Vue from 'vue'
import Index from './student-discussion-issue'

const index = new Vue(Index);

index.$mount();
