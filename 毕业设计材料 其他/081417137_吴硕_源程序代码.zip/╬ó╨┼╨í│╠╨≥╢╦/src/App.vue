<script>
export default {

}
</script>

<style lang="scss">
@import "./common/icon.css";

page {
  width: 100%;
  height: 100%;
}

.container {
  width: 100%;
  height: 100%;
}
</style>
