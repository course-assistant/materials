package cn.hncj.assistant.constance;

/**
 * 周目标枚举
 */
public class WeekGoalType {
    public static int REMEMBER = 1;
    public static int UNDERSTAND = 2;
    public static int APPLY = 3;
    public static int CREATE = 4;
}
