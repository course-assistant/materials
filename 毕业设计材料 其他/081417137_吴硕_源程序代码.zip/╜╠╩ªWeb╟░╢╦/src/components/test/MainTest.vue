<template>
  <div class="main-test">
    <router-view />
  </div>
</template>

<script>
  export default {
    name: "MainTest"
  }
</script>

<style scoped>
  .main-test{
    height: 100%;
  }
</style>