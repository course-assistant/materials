import Vue from 'vue'
import Index from './user-course-detail'

const index = new Vue(Index)

index.$mount()
