<template>
  <div>
    这是判断的页面
  </div>
</template>

<script>
  export default {
    name: "Judge"
  }
</script>

<style scoped>

</style>