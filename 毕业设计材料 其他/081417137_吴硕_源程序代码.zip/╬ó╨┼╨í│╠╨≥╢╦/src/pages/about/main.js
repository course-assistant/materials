import Vue from 'vue'
import Index from './about'

const index = new Vue(Index)

index.$mount()
