import Vue from 'vue'
import Index from './student-test-detail'

const index = new Vue(Index)

index.$mount()
