import Vue from 'vue'
import Index from './student-message-main'

const index = new Vue(Index)

index.$mount()
