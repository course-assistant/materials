import Vue from 'vue'
import Index from './demo'

const index = new Vue(Index)

index.$mount()
