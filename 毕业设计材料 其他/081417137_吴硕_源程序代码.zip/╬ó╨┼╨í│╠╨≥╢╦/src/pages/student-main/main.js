import Vue from 'vue'
import Index from './student-main'


const index = new Vue(Index)

index.$mount()
